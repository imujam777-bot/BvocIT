document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.getElementById("menuToggle");
  const nav = document.getElementById("mainNav");
  if (menuToggle && nav) menuToggle.addEventListener("click", () => nav.classList.toggle("open"));

  const homeSubjects = document.getElementById("homeSubjects");
  const subjectsList = document.getElementById("subjectsList");

  function subjectCard(subject) {
    const isAdvancedJava = subject.code === "1130501";
    const openTag = isAdvancedJava
      ? `<a class="subject-card subject-card-link" href="advanced-java.html" aria-label="Open Advanced Java study resources">`
      : `<article class="subject-card">`;
    const closeTag = isAdvancedJava ? `</a>` : `</article>`;
    const cta = isAdvancedJava ? `<span class="subject-open-cta">Open notes, diagrams & past papers <b>→</b></span>` : `<span class="subject-open-cta muted-cta">Resources will be added soon</span>`;
    return `${openTag}
      <div class="subject-card-top"><span class="subject-icon">${subject.code.slice(-2)}</span>
      <div><h3>${subject.name}</h3><span class="subject-code">${subject.code} · ${subject.units.length} UNITS</span>
      <p style="margin-top:7px">${subject.focus}</p></div></div>
      <ul class="unit-list">${subject.units.map(unit => `<li>${unit}</li>`).join("")}</ul>
      ${cta}${closeTag}`;
  }
  if (homeSubjects) homeSubjects.innerHTML = subjects.map(subjectCard).join("");
  if (subjectsList) subjectsList.innerHTML = subjects.map(subjectCard).join("");

  const list = document.getElementById("resourceList");
  if (!list) return;
  const search = document.getElementById("resourceSearch");
  const filter = document.getElementById("subjectFilter");
  subjects.forEach(subject => {
    const option = document.createElement("option");
    option.value = subject.code;
    option.textContent = subject.name;
    filter.appendChild(option);
  });

  function renderResources() {
    const query = (search?.value || "").trim().toLowerCase();
    const subjectCode = filter?.value || "";
    const visible = resources.filter(item => {
      const subject = subjects.find(s => s.code === item.subjectCode);
      const matchesQuery = [item.title, item.description, item.unit, item.type, subject?.name].join(" ").toLowerCase().includes(query);
      return matchesQuery && (!subjectCode || item.subjectCode === subjectCode);
    });
    if (!visible.length) {
      list.innerHTML = `<div class="empty-state">No resources match your search. Try another keyword or subject.</div>`;
      return;
    }
    list.innerHTML = visible.map(item => {
      const subject = subjects.find(s => s.code === item.subjectCode);
      const action = item.file
        ? `<a class="resource-link" href="${item.file}" target="_blank" rel="noopener">Open resource ↗</a>`
        : `<span class="resource-link">Sample entry · file not added yet</span>`;
      return `<article class="resource-card"><span class="resource-type">${item.type}</span><h3>${item.title}</h3><p>${item.description}</p><div class="resource-meta">${subject?.name || "Subject"} · ${item.unit} · ${item.priority}</div>${action}</article>`;
    }).join("");
  }
  search?.addEventListener("input", renderResources);
  filter?.addEventListener("change", renderResources);
  renderResources();
});
