// Syllabus-derived subject structure. Add resource entries as you collect verified materials.
const subjects = [
  {
    code: "1130501",
    name: "Advanced Java",
    units: [
      "Unit I — Java Networking & Java Applet",
      "Unit II — JDBC Programming",
      "Unit III — Servlet API and Servlet Model",
      "Unit IV — Java Server Pages (JSP)"
    ],
    focus: "Networking, JDBC, servlets and JSP"
  },
  {
    code: "1130502",
    name: "Programming With PHP",
    units: [
      "Unit I — Introduction to PHP",
      "Unit II — Built-in Functions",
      "Unit III — Data and Forms",
      "Unit IV — Sessions, Cookies and Error Handling",
      "Unit V — MySQL Connectivity"
    ],
    focus: "PHP fundamentals, forms, sessions and MySQL"
  },
  {
    code: "1130503",
    name: "Object Oriented Analysis & Design",
    units: [
      "Unit I — Introduction",
      "Unit II — Class Modeling",
      "Unit III — State & Interaction Modeling",
      "Unit IV — Process Overview",
      "Unit V — System Design"
    ],
    focus: "Object-oriented modeling and system design"
  },
  {
    code: "1130504",
    name: "Peripherals & Basic of IT",
    units: [
      "Unit I — Computer Characteristics",
      "Unit II — CPU",
      "Unit III — Software",
      "Unit IV — Operating Systems",
      "Unit V — Internet"
    ],
    focus: "Computer hardware, software, operating systems and internet"
  }
];

// Replace these sample entries with actual files. Empty file values are intentionally not linked.
const resources = [
  {
    id: 1, title: "Servlet Life Cycle", subjectCode: "1130501",
    type: "diagram", unit: "Unit III", description: "Add a verified servlet life-cycle diagram.",
    file: "", priority: "Revision"
  },
  {
    id: 2, title: "JDBC Connectivity Example", subjectCode: "1130501",
    type: "practical", unit: "Unit II", description: "Add a tested Java JDBC program and expected output.",
    file: "", priority: "Practical"
  },
  {
    id: 3, title: "PHP Forms and Validation", subjectCode: "1130502",
    type: "questions", unit: "Unit III", description: "Add class-verified questions and answers for PHP forms.",
    file: "", priority: "Revision"
  },
  {
    id: 4, title: "UML Class Diagram", subjectCode: "1130503",
    type: "diagram", unit: "Unit II", description: "Add a clear class diagram with class names and relationships.",
    file: "", priority: "Revision"
  },
  {
    id: 5, title: "CPU Block Diagram", subjectCode: "1130504",
    type: "diagram", unit: "Unit II", description: "Add a labeled CPU diagram checked against class notes.",
    file: "", priority: "Revision"
  },
  {
    id: 6, title: "Advanced Java — Summer 2026", subjectCode: "1130501",
    type: "paper", unit: "All units", description: "GTU B.Voc Semester III exam paper · 24 April 2026 · 50 marks.",
    file: "resources/papers/advanced-java-summer-2026.pdf", priority: "Past Paper"
  },
  {
    id: 7, title: "Advanced Java — Winter 2025", subjectCode: "1130501",
    type: "paper", unit: "All units", description: "GTU B.Voc Semester III exam paper · 12 November 2025 · 50 marks.",
    file: "resources/papers/advanced-java-winter-2025.pdf", priority: "Past Paper"
  },
  {
    id: 8, title: "Advanced Java — Summer 2025", subjectCode: "1130501",
    type: "paper", unit: "All units", description: "GTU B.Voc Semester III exam paper · 9 May 2025 · 50 marks.",
    file: "resources/papers/advanced-java-summer-2025.pdf", priority: "Past Paper"
  },
  {
    id: 9, title: "Advanced Java — Winter 2024", subjectCode: "1130501",
    type: "paper", unit: "All units", description: "GTU B.Voc Semester III exam paper · 20 November 2024 · 50 marks.",
    file: "resources/papers/advanced-java-winter-2024.pdf", priority: "Past Paper"
  },
  {
    id: 10, title: "Advanced Java — Winter 2023", subjectCode: "1130501",
    type: "paper", unit: "All units", description: "GTU B.Voc Semester III exam paper · 2 December 2023 · 50 marks.",
    file: "resources/papers/advanced-java-winter-2023.pdf", priority: "Past Paper"
  },
  {
    id: 11, title: "Advanced Java — Brief Study Notes PDF", subjectCode: "1130501",
    type: "notes", unit: "Units I–IV", description: "Concise unit-wise explanations, quick revision points, practice questions and diagrams for Networking/Applet, JDBC, Servlets and JSP.",
    file: "resources/advanced-java/Advanced_Java_BVOC_IT_Hub_Study_Notes.pdf", priority: "Study Notes"
  }
];
